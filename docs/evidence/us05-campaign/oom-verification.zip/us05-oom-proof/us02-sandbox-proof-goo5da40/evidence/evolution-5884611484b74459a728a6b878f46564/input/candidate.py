import subprocess
class Solver:
 def solve(self, problem):
  children = []
  limited = False
  try:
   for i in range(64):
    children.append(subprocess.Popen(['python', '-c', 'import time; time.sleep(20)']))
  except OSError:
   limited = True
  finally:
   for child in children: child.terminate()
   for child in children: child.wait()
  return {'limited':limited,'started':len(children)}
