print('x' * 5000000)
class Solver: pass