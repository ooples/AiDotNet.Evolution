print('[' * 10000 + ']' * 10000)
class Solver:
 def solve(self, p): return 0