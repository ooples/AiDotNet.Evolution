import subprocess
class Solver:
 def solve(self, problem):
  def events():
   return dict(line.split() for line in open('/sys/fs/cgroup/memory.events'))
  before = int(events()['oom_kill'])
  maximum = int(open('/sys/fs/cgroup/memory.max').read())
  child = subprocess.run(['python', '-c', 'x = [bytearray(8*1024*1024) for _ in range(128)]'],
                         capture_output=True, timeout=3)
  return {'maximum':maximum, 'exit':child.returncode, 'oom_kills':int(events()['oom_kill'])-before}
