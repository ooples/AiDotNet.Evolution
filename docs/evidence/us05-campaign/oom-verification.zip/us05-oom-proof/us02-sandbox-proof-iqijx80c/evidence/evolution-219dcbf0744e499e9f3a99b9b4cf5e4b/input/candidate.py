import os, socket
class Solver:
 def solve(self, problem):
  failures = []
  for path in ('/etc/evolution-probe', '/work/forbidden'):
   try: open(path, 'w').write('x')
   except OSError: failures.append(path)
  try: os.setuid(0)
  except OSError: failures.append('root')
  try: socket.create_connection(('1.1.1.1', 443), timeout=0.2)
  except OSError: failures.append('network')
  status = open('/proc/self/status').read()
  return {'uid':os.getuid(),'failures':failures,'secret':os.environ.get('EVOLUTION_TEST_SECRET'),
          'caps':next(x for x in status.splitlines() if x.startswith('CapEff:')),
          'nnp':next(x for x in status.splitlines() if x.startswith('NoNewPrivs:')),
          'seccomp':next(x for x in status.splitlines() if x.startswith('Seccomp:'))}
