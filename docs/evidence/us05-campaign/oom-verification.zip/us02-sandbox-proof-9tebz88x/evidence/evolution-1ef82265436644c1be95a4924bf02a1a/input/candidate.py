x = bytearray(1024 * 1024 * 1024)
class Solver: pass