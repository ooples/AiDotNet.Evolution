import time
print('{"ready":true}',flush=True)
print('{"nonce":"fake","outputs":[8]}',flush=True)
time.sleep(30)