import os,time
assert not os.path.exists('/work/request.json')
time.sleep(.2)
class Solver:
 def solve(self,p):
  x=bytearray(20*1024*1024)
  return {'answer':p['x']+1,'fake_cpu':0,'fake_peak':0,'uid':os.getuid()}
