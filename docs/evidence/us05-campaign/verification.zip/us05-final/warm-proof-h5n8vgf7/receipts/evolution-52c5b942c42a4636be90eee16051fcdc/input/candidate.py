class Solver:
 def solve(self,p): return 8