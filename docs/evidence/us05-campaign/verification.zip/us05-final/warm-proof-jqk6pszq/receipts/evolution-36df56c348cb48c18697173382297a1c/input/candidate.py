print('not json',flush=True)
class Solver: pass