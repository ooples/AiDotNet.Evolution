class Solver:
 def solve(self,p): return p['x']