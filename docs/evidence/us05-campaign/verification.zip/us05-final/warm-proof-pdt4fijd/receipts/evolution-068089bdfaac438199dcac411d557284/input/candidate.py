import time
print('{"ready":true}',flush=True)
time.sleep(30)