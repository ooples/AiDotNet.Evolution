class Solver:
 def solve(self,p): return p['x']+1
# fixture-4
