class Solver:
 def solve(self,p): return {'solution':[.5,.5]}
