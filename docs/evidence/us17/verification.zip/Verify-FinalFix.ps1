$ErrorActionPreference = 'Stop'
$env:TEMP = 'F:/ooples-temp/evolution-consolidation-temp'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = 'F:/ooples-temp/evolution-consolidation-temp/dotnet-home'
$env:NUGET_HTTP_CACHE_PATH = 'F:/ooples-temp/evolution-consolidation-temp/nuget-http'
$logs = 'F:/ooples-temp/AiDotNet.Evolution-us17/.local/verification'
function Check([string]$Name, [string[]]$Arguments) {
    & dotnet @Arguments *> "$logs/final-$Name.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$logs/final-$Name.log" -Tail 20; throw "$Name failed" }
    Write-Output "$Name passed"
}
foreach ($framework in @('net10.0', 'net8.0')) {
    Check "compiler-$framework" @('test', 'tests/AiDotNet.Evolution.CSharp.Tests', '-c', 'Release', '-f', $framework,
        '--no-restore', '--logger', 'trx', '--results-directory', "$logs/final-compiler-$framework")
    Check "example-$framework" @('run', '--project', 'examples/CompilerGuidedSearch', '-c', 'Release', '-f', $framework,
        '--no-restore', '--', "$logs/final-example-$framework")
}
Check 'pack-programs' @('pack', 'src/AiDotNet.Evolution.Programs', '-c', 'Release', '--no-restore', '-o', '.local/final-packages')
Check 'pack-csharp' @('pack', 'src/AiDotNet.Evolution.CSharp', '-c', 'Release', '--no-restore', '-o', '.local/final-packages')
Check 'format' @('format', 'AiDotNet.Evolution.slnx', '--no-restore', '--verify-no-changes')
