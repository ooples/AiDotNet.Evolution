param([switch]$Resume)
$ErrorActionPreference = 'Stop'
$env:TEMP = 'F:/ooples-temp/evolution-consolidation-temp'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = 'F:/ooples-temp/evolution-consolidation-temp/dotnet-home'
$env:NUGET_HTTP_CACHE_PATH = 'F:/ooples-temp/evolution-consolidation-temp/nuget-http'
$logs = 'F:/ooples-temp/AiDotNet.Evolution-us17/.local/verification'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
function Invoke-Check([string]$Name, [string[]]$Arguments) {
    $logPath = "$logs/$Name.log"
    if (Test-Path $logPath) { $logPath = "$logs/$Name-$(Get-Date -Format yyyyMMdd-HHmmss).log" }
    & dotnet @Arguments 2>&1 | Tee-Object -FilePath $logPath
    if ($LASTEXITCODE -ne 0) { throw "$Name failed: $LASTEXITCODE" }
}
if (!$Resume) {
Invoke-Check 'restore' @('restore', 'AiDotNet.Evolution.slnx', '--verbosity', 'minimal')
Invoke-Check 'format-apply' @('format', 'AiDotNet.Evolution.slnx', '--no-restore', '--include',
    'src/AiDotNet.Evolution.Programs', 'src/AiDotNet.Evolution.CSharp',
    'tests/AiDotNet.Evolution.CSharp.Tests', 'examples/CompilerGuidedSearch')
}
Invoke-Check 'build' @('build', 'AiDotNet.Evolution.slnx', '-c', 'Release', '--no-restore', '--verbosity', 'minimal')
foreach ($framework in @('net10.0', 'net8.0', 'net471')) {
    Invoke-Check "core-$framework" @('test', 'tests/AiDotNet.Evolution.Tests', '-c', 'Release', '-f', $framework,
        '--no-build', '--no-restore', '--logger', 'trx', '--results-directory', "$logs/core-$framework")
}
foreach ($framework in @('net10.0', 'net8.0')) {
    Invoke-Check "compiler-$framework" @('test', 'tests/AiDotNet.Evolution.CSharp.Tests', '-c', 'Release', '-f', $framework,
        '--no-build', '--no-restore', '--logger', 'trx', '--collect:XPlat Code Coverage', '--results-directory', "$logs/compiler-$framework")
    Invoke-Check "example-$framework" @('run', '--project', 'examples/CompilerGuidedSearch', '-c', 'Release', '-f', $framework,
        '--no-build', '--no-restore', '--', "$logs/example-$framework")
}
Invoke-Check 'format-verify' @('format', 'AiDotNet.Evolution.slnx', '--no-restore', '--verify-no-changes')
