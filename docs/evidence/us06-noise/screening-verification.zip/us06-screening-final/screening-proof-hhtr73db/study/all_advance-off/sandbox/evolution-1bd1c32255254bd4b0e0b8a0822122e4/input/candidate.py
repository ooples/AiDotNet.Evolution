class Solver:
 def solve(self,p):
  for _ in range(30):
   result=sorted(p['values'])
  return result
