class Solver:
 def solve(self,p):
  for _ in range(1):
   result=sorted(p['values'])
  return result
# fast-2
