class Solver:
 def solve(self,p):
  for _ in range(4000):
   result=sorted(p['values'])
  return result
# slow-2
