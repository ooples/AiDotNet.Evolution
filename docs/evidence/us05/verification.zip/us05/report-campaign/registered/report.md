# Numeric development analysis

Source: `2f5f33815fe631ae4fb4bb0e2b8e57c1afa5490e`.

Prospectively fixed development schedule. No held-out or competitive-win claim.

Endpoint: mean task-balanced paired difference in scale/(scale+final loss); failures have utility 0.

Intervals use 200 paired bootstrap replicates, with 95% nominal family-wise confidence after adjusting aggregate comparisons.
Tasks are fixed; intervals describe seed variability on this suite only.

## Paired effects

Positive differences favor the primary method. Failed, incomplete and missing runs remain in the denominator.

| Primary | Comparator | Utility difference | Adjusted bootstrap interval |
| --- | --- | ---: | --- |
| DiagonalCma | RandomSearch | -0.0010286 | [-0.00243296, -1.88341e-05] |
| DiagonalCma | HillClimb | -0.000509183 | [-0.00106879, 0.000307342] |
| DiagonalCma | FixedMapElites | 0.000948415 | [0.000355986, 0.00147586] |
| DiagonalCma | AdaptiveMapElites | -0.000628067 | [-0.00204465, 0.000558383] |
| DiagonalCma | UniformPortfolioMapElites | -0.00037353 | [-0.00127148, 0.000416417] |

## Every task and method

Loss medians below are completed-only; utility includes every scheduled run.

| Task | Method | Completed / planned | Median loss | Mean utility | Incomplete traces |
| --- | --- | ---: | ---: | ---: | ---: |
| Sphere | RandomSearch | 55 / 55 | 32.1031 | 0.0352343 | 0 |
| Sphere | HillClimb | 55 / 55 | 33.0869 | 0.0332572 | 0 |
| Sphere | FixedMapElites | 55 / 55 | 35.5858 | 0.0312364 | 0 |
| Sphere | AdaptiveMapElites | 55 / 55 | 33.0584 | 0.033826 | 0 |
| Sphere | UniformPortfolioMapElites | 55 / 55 | 32.6422 | 0.0335709 | 0 |
| Sphere | DiagonalCma | 55 / 55 | 33.0584 | 0.0330297 | 0 |
| ShiftedQuadratic | RandomSearch | 55 / 55 | 29.2342 | 0.0338947 | 0 |
| ShiftedQuadratic | HillClimb | 55 / 55 | 34.705 | 0.0327603 | 0 |
| ShiftedQuadratic | FixedMapElites | 55 / 55 | 37.2038 | 0.0307801 | 0 |
| ShiftedQuadratic | AdaptiveMapElites | 55 / 55 | 33.8088 | 0.0337584 | 0 |
| ShiftedQuadratic | UniformPortfolioMapElites | 55 / 55 | 31.2545 | 0.033288 | 0 |
| ShiftedQuadratic | DiagonalCma | 55 / 55 | 33.9242 | 0.0322712 | 0 |
| AnisotropicQuadratic | RandomSearch | 55 / 55 | 647.939 | 0.00193356 | 0 |
| AnisotropicQuadratic | HillClimb | 55 / 55 | 737.329 | 0.00181871 | 0 |
| AnisotropicQuadratic | FixedMapElites | 55 / 55 | 770.253 | 0.00166361 | 0 |
| AnisotropicQuadratic | AdaptiveMapElites | 55 / 55 | 713.106 | 0.00177914 | 0 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 55 / 55 | 714.723 | 0.00177994 | 0 |
| AnisotropicQuadratic | DiagonalCma | 55 / 55 | 627.622 | 0.00192656 | 0 |
| RippledQuadratic | RandomSearch | 55 / 55 | 99.708 | 0.0103878 | 0 |
| RippledQuadratic | HillClimb | 55 / 55 | 89.1358 | 0.0115365 | 0 |
| RippledQuadratic | FixedMapElites | 55 / 55 | 104.204 | 0.00986226 | 0 |
| RippledQuadratic | AdaptiveMapElites | 55 / 55 | 100.233 | 0.0104847 | 0 |
| RippledQuadratic | UniformPortfolioMapElites | 55 / 55 | 100.621 | 0.0101912 | 0 |
| RippledQuadratic | DiagonalCma | 55 / 55 | 100.212 | 0.0101085 | 0 |

## Failed or missing runs

None.

## Interpretation limits

- Schedule frozen before this dispatch; development tasks are not sealed holdouts and no release promotion follows.
- Protocol-v4 external convergence is valid below the cap; its final measured incumbent carries forward without invented measurements.
- Timing samples and trajectory points are not independent search runs.
- Intervals are approximate; small or degenerate samples can understate uncertainty.
- Completed-only losses and known-only curves are descriptive, not failure-inclusive comparison endpoints.
- Task resampling does not make a purposively selected suite representative.

## Measurement scorecard

Known work totals are lower bounds when work is unknown. Completion is not independent correctness.

| Task | Method | Accounted completion | Known-only utility AUC | AUC known / scheduled |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 1 | 0.0276155 | 55 / 55 |
| Sphere | HillClimb | 1 | 0.0269556 | 55 / 55 |
| Sphere | FixedMapElites | 1 | 0.0264864 | 55 / 55 |
| Sphere | AdaptiveMapElites | 1 | 0.0270062 | 55 / 55 |
| Sphere | UniformPortfolioMapElites | 1 | 0.0270158 | 55 / 55 |
| Sphere | DiagonalCma | 1 | 0.0270102 | 55 / 55 |
| ShiftedQuadratic | RandomSearch | 1 | 0.0269105 | 55 / 55 |
| ShiftedQuadratic | HillClimb | 1 | 0.0265123 | 55 / 55 |
| ShiftedQuadratic | FixedMapElites | 1 | 0.0260727 | 55 / 55 |
| ShiftedQuadratic | AdaptiveMapElites | 1 | 0.0265352 | 55 / 55 |
| ShiftedQuadratic | UniformPortfolioMapElites | 1 | 0.0265165 | 55 / 55 |
| ShiftedQuadratic | DiagonalCma | 1 | 0.026481 | 55 / 55 |
| AnisotropicQuadratic | RandomSearch | 1 | 0.0014269 | 55 / 55 |
| AnisotropicQuadratic | HillClimb | 1 | 0.00139305 | 55 / 55 |
| AnisotropicQuadratic | FixedMapElites | 1 | 0.00135823 | 55 / 55 |
| AnisotropicQuadratic | AdaptiveMapElites | 1 | 0.0013805 | 55 / 55 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 1 | 0.00138023 | 55 / 55 |
| AnisotropicQuadratic | DiagonalCma | 1 | 0.00143536 | 55 / 55 |
| RippledQuadratic | RandomSearch | 1 | 0.00874926 | 55 / 55 |
| RippledQuadratic | HillClimb | 1 | 0.00895234 | 55 / 55 |
| RippledQuadratic | FixedMapElites | 1 | 0.00856215 | 55 / 55 |
| RippledQuadratic | AdaptiveMapElites | 1 | 0.00872114 | 55 / 55 |
| RippledQuadratic | UniformPortfolioMapElites | 1 | 0.00865974 | 55 / 55 |
| RippledQuadratic | DiagonalCma | 1 | 0.00862849 | 55 / 55 |

Correctness pass rate, numerical error, runtime speedup, memory, undeclared targets,
common-grid coverage and normalized QD score are **unknown**, not zero or inferred from completion.
Actual available resource totals and their unknown-run counts are retained in JSON.
Declared target rates include all scheduled runs; non-hits are censored at the budget with unknown trajectories flagged separately.

## Budget-indexed progress

Known-only medians; missing curves are not interpolated.

| Task | Method | Cost units | Known / scheduled | Median loss |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 8 | 55 / 55 | 35.6504 |
| Sphere | RandomSearch | 16 | 55 / 55 | 32.1031 |
| Sphere | HillClimb | 8 | 55 / 55 | 35.6504 |
| Sphere | HillClimb | 16 | 55 / 55 | 33.0869 |
| Sphere | FixedMapElites | 8 | 55 / 55 | 35.6504 |
| Sphere | FixedMapElites | 16 | 55 / 55 | 35.5858 |
| Sphere | AdaptiveMapElites | 8 | 55 / 55 | 35.6504 |
| Sphere | AdaptiveMapElites | 16 | 55 / 55 | 33.0584 |
| Sphere | UniformPortfolioMapElites | 8 | 55 / 55 | 35.6504 |
| Sphere | UniformPortfolioMapElites | 16 | 55 / 55 | 32.6422 |
| Sphere | DiagonalCma | 8 | 55 / 55 | 35.6504 |
| Sphere | DiagonalCma | 16 | 55 / 55 | 33.0584 |
| ShiftedQuadratic | RandomSearch | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | RandomSearch | 16 | 55 / 55 | 29.2342 |
| ShiftedQuadratic | HillClimb | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | HillClimb | 16 | 55 / 55 | 34.705 |
| ShiftedQuadratic | FixedMapElites | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | FixedMapElites | 16 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 33.8088 |
| ShiftedQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 31.2545 |
| ShiftedQuadratic | DiagonalCma | 8 | 55 / 55 | 37.2038 |
| ShiftedQuadratic | DiagonalCma | 16 | 55 / 55 | 33.9242 |
| AnisotropicQuadratic | RandomSearch | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | RandomSearch | 16 | 55 / 55 | 647.939 |
| AnisotropicQuadratic | HillClimb | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | HillClimb | 16 | 55 / 55 | 737.329 |
| AnisotropicQuadratic | FixedMapElites | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | FixedMapElites | 16 | 55 / 55 | 770.253 |
| AnisotropicQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 713.106 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 714.723 |
| AnisotropicQuadratic | DiagonalCma | 8 | 55 / 55 | 774.219 |
| AnisotropicQuadratic | DiagonalCma | 16 | 55 / 55 | 627.622 |
| RippledQuadratic | RandomSearch | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | RandomSearch | 16 | 55 / 55 | 99.708 |
| RippledQuadratic | HillClimb | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | HillClimb | 16 | 55 / 55 | 89.1358 |
| RippledQuadratic | FixedMapElites | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | FixedMapElites | 16 | 55 / 55 | 104.204 |
| RippledQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 100.233 |
| RippledQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 100.621 |
| RippledQuadratic | DiagonalCma | 8 | 55 / 55 | 105.207 |
| RippledQuadratic | DiagonalCma | 16 | 55 / 55 | 100.212 |

## Paired win / tie / loss counts

Exact utility differences; failures remain paired.

- DiagonalCma versus RandomSearch: 49 / 93 / 78.
- DiagonalCma versus HillClimb: 44 / 0 / 176.
- DiagonalCma versus FixedMapElites: 67 / 98 / 55.
- DiagonalCma versus AdaptiveMapElites: 54 / 103 / 63.
- DiagonalCma versus UniformPortfolioMapElites: 56 / 112 / 52.

## Locked fixed-sample analysis

Registration: `316fd8a7dbe2c684f8a23ebef0a2459988e78b1de299645b7d65c38eaf2d4a56`.
No sample extension is permitted. One-sided Hoeffding lower bounds below are separate from descriptive bootstrap intervals; no release promotion follows.

- RandomSearch: lower bound -0.467796; above zero: False.
- HillClimb: lower bound -0.467276; above zero: False.
- FixedMapElites: lower bound -0.465819; above zero: False.
- AdaptiveMapElites: lower bound -0.467395; above zero: False.
- UniformPortfolioMapElites: lower bound -0.467141; above zero: False.

Task-level exploratory intervals, budget-indexed progress, independent resource counters and every run are in `report.json`.
Full unaggregated trajectories remain in the original input, identified by its SHA-256 in the report.
