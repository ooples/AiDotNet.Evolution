# Numeric development analysis

Source: `1c4d6b49dbac27d71b23e72481c2165e01ed9ab5`.

Prospectively fixed development schedule. No held-out or competitive-win claim.

Endpoint: mean task-balanced paired difference in scale/(scale+final loss); failures have utility 0.

Intervals use 200 paired bootstrap replicates, with 95% nominal family-wise confidence after adjusting aggregate comparisons.
Tasks are fixed; intervals describe seed variability on this suite only.

## Paired effects

Positive differences favor the primary method. Failed, incomplete and missing runs remain in the denominator.

| Primary | Comparator | Utility difference | Adjusted bootstrap interval |
| --- | --- | ---: | --- |
| DiagonalCma | RandomSearch | -0.00222327 | [-0.00615195, 0.000421631] |
| DiagonalCma | HillClimb | -0.000165514 | [-0.000798003, 0.000534051] |
| DiagonalCma | FixedMapElites | 0.00108632 | [0.000419039, 0.00222528] |
| DiagonalCma | AdaptiveMapElites | -0.000300801 | [-0.00129334, 0.000784909] |
| DiagonalCma | UniformPortfolioMapElites | -0.000400992 | [-0.00164331, 0.00086223] |

## Every task and method

Loss medians below are completed-only; utility includes every scheduled run.

| Task | Method | Completed / planned | Median loss | Mean utility | Incomplete traces |
| --- | --- | ---: | ---: | ---: | ---: |
| Sphere | RandomSearch | 55 / 55 | 31.1881 | 0.0362635 | 0 |
| Sphere | HillClimb | 55 / 55 | 32.5031 | 0.0317767 | 0 |
| Sphere | FixedMapElites | 55 / 55 | 34.4372 | 0.03004 | 0 |
| Sphere | AdaptiveMapElites | 55 / 55 | 31.9409 | 0.0322015 | 0 |
| Sphere | UniformPortfolioMapElites | 55 / 55 | 32.7712 | 0.0322624 | 0 |
| Sphere | DiagonalCma | 55 / 55 | 31.5297 | 0.0314633 | 0 |
| ShiftedQuadratic | RandomSearch | 55 / 55 | 32.5674 | 0.03555 | 0 |
| ShiftedQuadratic | HillClimb | 55 / 55 | 35.3104 | 0.0310407 | 0 |
| ShiftedQuadratic | FixedMapElites | 55 / 55 | 37.3156 | 0.0293394 | 0 |
| ShiftedQuadratic | AdaptiveMapElites | 55 / 55 | 35.3587 | 0.0319805 | 0 |
| ShiftedQuadratic | UniformPortfolioMapElites | 55 / 55 | 35.3587 | 0.0323018 | 0 |
| ShiftedQuadratic | DiagonalCma | 55 / 55 | 37.1167 | 0.0316751 | 0 |
| AnisotropicQuadratic | RandomSearch | 55 / 55 | 554.839 | 0.00213104 | 0 |
| AnisotropicQuadratic | HillClimb | 55 / 55 | 676.142 | 0.00178298 | 0 |
| AnisotropicQuadratic | FixedMapElites | 55 / 55 | 727.639 | 0.00166759 | 0 |
| AnisotropicQuadratic | AdaptiveMapElites | 55 / 55 | 648.435 | 0.00181636 | 0 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 55 / 55 | 588.334 | 0.00185661 | 0 |
| AnisotropicQuadratic | DiagonalCma | 55 / 55 | 609.815 | 0.00181416 | 0 |
| RippledQuadratic | RandomSearch | 55 / 55 | 98.9856 | 0.0102357 | 0 |
| RippledQuadratic | HillClimb | 55 / 55 | 91.5086 | 0.0113488 | 0 |
| RippledQuadratic | FixedMapElites | 55 / 55 | 102.106 | 0.00989489 | 0 |
| RippledQuadratic | AdaptiveMapElites | 55 / 55 | 97.0249 | 0.010492 | 0 |
| RippledQuadratic | UniformPortfolioMapElites | 55 / 55 | 95.1529 | 0.0104703 | 0 |
| RippledQuadratic | DiagonalCma | 55 / 55 | 96.7877 | 0.0103347 | 0 |

## Failed or missing runs

None.

## Interpretation limits

- Schedule frozen before this dispatch; development tasks are not sealed holdouts and no release promotion follows.
- Protocol-v4 external convergence is valid below the cap; its final measured incumbent carries forward without invented measurements.
- Timing samples and trajectory points are not independent search runs.
- Intervals are approximate; small or degenerate samples can understate uncertainty.
- Completed-only losses and known-only curves are descriptive, not failure-inclusive comparison endpoints.
- Task resampling does not make a purposively selected suite representative.

## Measurement scorecard

Known work totals are lower bounds when work is unknown. Completion is not independent correctness.

| Task | Method | Accounted completion | Known-only utility AUC | AUC known / scheduled |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 1 | 0.0270764 | 55 / 55 |
| Sphere | HillClimb | 1 | 0.0260429 | 55 / 55 |
| Sphere | FixedMapElites | 1 | 0.0257031 | 55 / 55 |
| Sphere | AdaptiveMapElites | 1 | 0.0262098 | 55 / 55 |
| Sphere | UniformPortfolioMapElites | 1 | 0.0262438 | 55 / 55 |
| Sphere | DiagonalCma | 1 | 0.0260622 | 55 / 55 |
| ShiftedQuadratic | RandomSearch | 1 | 0.0266586 | 55 / 55 |
| ShiftedQuadratic | HillClimb | 1 | 0.0255789 | 55 / 55 |
| ShiftedQuadratic | FixedMapElites | 1 | 0.0252468 | 55 / 55 |
| ShiftedQuadratic | AdaptiveMapElites | 1 | 0.0259279 | 55 / 55 |
| ShiftedQuadratic | UniformPortfolioMapElites | 1 | 0.0259899 | 55 / 55 |
| ShiftedQuadratic | DiagonalCma | 1 | 0.0258994 | 55 / 55 |
| AnisotropicQuadratic | RandomSearch | 1 | 0.00149301 | 55 / 55 |
| AnisotropicQuadratic | HillClimb | 1 | 0.00139724 | 55 / 55 |
| AnisotropicQuadratic | FixedMapElites | 1 | 0.00137075 | 55 / 55 |
| AnisotropicQuadratic | AdaptiveMapElites | 1 | 0.00141077 | 55 / 55 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 1 | 0.00141728 | 55 / 55 |
| AnisotropicQuadratic | DiagonalCma | 1 | 0.00140442 | 55 / 55 |
| RippledQuadratic | RandomSearch | 1 | 0.00873325 | 55 / 55 |
| RippledQuadratic | HillClimb | 1 | 0.0089235 | 55 / 55 |
| RippledQuadratic | FixedMapElites | 1 | 0.00862433 | 55 / 55 |
| RippledQuadratic | AdaptiveMapElites | 1 | 0.00877896 | 55 / 55 |
| RippledQuadratic | UniformPortfolioMapElites | 1 | 0.00880565 | 55 / 55 |
| RippledQuadratic | DiagonalCma | 1 | 0.00879849 | 55 / 55 |

Correctness pass rate, numerical error, runtime speedup, memory, undeclared targets,
common-grid coverage and normalized QD score are **unknown**, not zero or inferred from completion.
Actual available resource totals and their unknown-run counts are retained in JSON.
Declared target rates include all scheduled runs; non-hits are censored at the budget with unknown trajectories flagged separately.

## Budget-indexed progress

Known-only medians; missing curves are not interpolated.

| Task | Method | Cost units | Known / scheduled | Median loss |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 8 | 55 / 55 | 34.927 |
| Sphere | RandomSearch | 16 | 55 / 55 | 31.1881 |
| Sphere | HillClimb | 8 | 55 / 55 | 34.927 |
| Sphere | HillClimb | 16 | 55 / 55 | 32.5031 |
| Sphere | FixedMapElites | 8 | 55 / 55 | 34.927 |
| Sphere | FixedMapElites | 16 | 55 / 55 | 34.4372 |
| Sphere | AdaptiveMapElites | 8 | 55 / 55 | 34.927 |
| Sphere | AdaptiveMapElites | 16 | 55 / 55 | 31.9409 |
| Sphere | UniformPortfolioMapElites | 8 | 55 / 55 | 34.927 |
| Sphere | UniformPortfolioMapElites | 16 | 55 / 55 | 32.7712 |
| Sphere | DiagonalCma | 8 | 55 / 55 | 34.927 |
| Sphere | DiagonalCma | 16 | 55 / 55 | 31.5297 |
| ShiftedQuadratic | RandomSearch | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | RandomSearch | 16 | 55 / 55 | 32.5674 |
| ShiftedQuadratic | HillClimb | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | HillClimb | 16 | 55 / 55 | 35.3104 |
| ShiftedQuadratic | FixedMapElites | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | FixedMapElites | 16 | 55 / 55 | 37.3156 |
| ShiftedQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 35.3587 |
| ShiftedQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 35.3587 |
| ShiftedQuadratic | DiagonalCma | 8 | 55 / 55 | 37.7815 |
| ShiftedQuadratic | DiagonalCma | 16 | 55 / 55 | 37.1167 |
| AnisotropicQuadratic | RandomSearch | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | RandomSearch | 16 | 55 / 55 | 554.839 |
| AnisotropicQuadratic | HillClimb | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | HillClimb | 16 | 55 / 55 | 676.142 |
| AnisotropicQuadratic | FixedMapElites | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | FixedMapElites | 16 | 55 / 55 | 727.639 |
| AnisotropicQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 648.435 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 588.334 |
| AnisotropicQuadratic | DiagonalCma | 8 | 55 / 55 | 761.834 |
| AnisotropicQuadratic | DiagonalCma | 16 | 55 / 55 | 609.815 |
| RippledQuadratic | RandomSearch | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | RandomSearch | 16 | 55 / 55 | 98.9856 |
| RippledQuadratic | HillClimb | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | HillClimb | 16 | 55 / 55 | 91.5086 |
| RippledQuadratic | FixedMapElites | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | FixedMapElites | 16 | 55 / 55 | 102.106 |
| RippledQuadratic | AdaptiveMapElites | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | AdaptiveMapElites | 16 | 55 / 55 | 97.0249 |
| RippledQuadratic | UniformPortfolioMapElites | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | UniformPortfolioMapElites | 16 | 55 / 55 | 95.1529 |
| RippledQuadratic | DiagonalCma | 8 | 55 / 55 | 106.574 |
| RippledQuadratic | DiagonalCma | 16 | 55 / 55 | 96.7877 |

## Paired win / tie / loss counts

Exact utility differences; failures remain paired.

- DiagonalCma versus RandomSearch: 46 / 97 / 77.
- DiagonalCma versus HillClimb: 51 / 1 / 168.
- DiagonalCma versus FixedMapElites: 65 / 89 / 66.
- DiagonalCma versus AdaptiveMapElites: 52 / 90 / 78.
- DiagonalCma versus UniformPortfolioMapElites: 49 / 90 / 81.

## Locked fixed-sample analysis

Registration: `dc945646c8e1e7624acc8cbf6dd79ae81ae78d5a01455f6c8078ef02620902cc`.
No sample extension is permitted. One-sided Hoeffding lower bounds below are separate from descriptive bootstrap intervals; no release promotion follows.

- RandomSearch: lower bound -0.46899; above zero: False.
- HillClimb: lower bound -0.466933; above zero: False.
- FixedMapElites: lower bound -0.465681; above zero: False.
- AdaptiveMapElites: lower bound -0.467068; above zero: False.
- UniformPortfolioMapElites: lower bound -0.467168; above zero: False.

Task-level exploratory intervals, budget-indexed progress, independent resource counters and every run are in `report.json`.
Full unaggregated trajectories remain in the original input, identified by its SHA-256 in the report.
