# Numeric development analysis

Source: `1c4d6b49dbac27d71b23e72481c2165e01ed9ab5`.

Retrospective only. No confirmatory or competitive-win claim.

Endpoint: mean task-balanced paired difference in scale/(scale+final loss); failures have utility 0.

Intervals use 200 paired bootstrap replicates, with 95% nominal family-wise confidence after adjusting aggregate comparisons.
Tasks are fixed; intervals describe seed variability on this suite only.

## Paired effects

Positive differences favor the primary method. Failed, incomplete and missing runs remain in the denominator.

| Primary | Comparator | Utility difference | Adjusted bootstrap interval |
| --- | --- | ---: | --- |
| DiagonalCma | RandomSearch | -0.0064942 | [-0.0140342, 0.00104581] |
| DiagonalCma | HillClimb | -0.00052973 | [-0.000864064, -0.000153606] |
| DiagonalCma | FixedMapElites | 0.000613561 | [-0.000226596, 0.00140716] |
| DiagonalCma | AdaptiveMapElites | 0.000452704 | [-0.000226466, 0.001132] |
| DiagonalCma | UniformPortfolioMapElites | 0.000592768 | [-0.000294648, 0.00148018] |

## Every task and method

Loss medians below are completed-only; utility includes every scheduled run.

| Task | Method | Completed / planned | Median loss | Mean utility | Incomplete traces |
| --- | --- | ---: | ---: | ---: | ---: |
| Sphere | RandomSearch | 2 / 2 | 26.0139 | 0.0383755 | 0 |
| Sphere | HillClimb | 2 / 2 | 31.0888 | 0.0312677 | 0 |
| Sphere | FixedMapElites | 2 / 2 | 32.1788 | 0.030172 | 0 |
| Sphere | AdaptiveMapElites | 2 / 2 | 32.1788 | 0.030172 | 0 |
| Sphere | UniformPortfolioMapElites | 2 / 2 | 32.1788 | 0.030172 | 0 |
| Sphere | DiagonalCma | 2 / 2 | 32.6283 | 0.0297989 | 0 |
| ShiftedQuadratic | RandomSearch | 2 / 2 | 24.7118 | 0.0442167 | 0 |
| ShiftedQuadratic | HillClimb | 2 / 2 | 37.9035 | 0.0264344 | 0 |
| ShiftedQuadratic | FixedMapElites | 2 / 2 | 39.0487 | 0.0254346 | 0 |
| ShiftedQuadratic | AdaptiveMapElites | 2 / 2 | 39.0487 | 0.0254346 | 0 |
| ShiftedQuadratic | UniformPortfolioMapElites | 2 / 2 | 38.7708 | 0.0255707 | 0 |
| ShiftedQuadratic | DiagonalCma | 2 / 2 | 39.6654 | 0.0251441 | 0 |
| AnisotropicQuadratic | RandomSearch | 2 / 2 | 728.115 | 0.00146 | 0 |
| AnisotropicQuadratic | HillClimb | 2 / 2 | 755.104 | 0.00145437 | 0 |
| AnisotropicQuadratic | FixedMapElites | 2 / 2 | 812.865 | 0.00133385 | 0 |
| AnisotropicQuadratic | AdaptiveMapElites | 2 / 2 | 812.865 | 0.00133385 | 0 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 2 / 2 | 812.865 | 0.00133385 | 0 |
| AnisotropicQuadratic | DiagonalCma | 2 / 2 | 720.118 | 0.00143769 | 0 |
| RippledQuadratic | RandomSearch | 2 / 2 | 97.5901 | 0.010243 | 0 |
| RippledQuadratic | HillClimb | 2 / 2 | 89.5577 | 0.0112808 | 0 |
| RippledQuadratic | FixedMapElites | 2 / 2 | 113.438 | 0.00892376 | 0 |
| RippledQuadratic | AdaptiveMapElites | 2 / 2 | 103.998 | 0.00956719 | 0 |
| RippledQuadratic | UniformPortfolioMapElites | 2 / 2 | 114.359 | 0.00887083 | 0 |
| RippledQuadratic | DiagonalCma | 2 / 2 | 83.9531 | 0.0119378 | 0 |

## Failed or missing runs

None.

## Interpretation limits

- Retrospective development analysis; no preregistration, power guarantee, release gate or competitor superiority claim.
- Protocol-v4 external convergence is valid below the cap; its final measured incumbent carries forward without invented measurements.
- Timing samples and trajectory points are not independent search runs.
- Intervals are approximate; small or degenerate samples can understate uncertainty.
- Completed-only losses and known-only curves are descriptive, not failure-inclusive comparison endpoints.
- Task resampling does not make a purposively selected suite representative.

## Measurement scorecard

Known work totals are lower bounds when work is unknown. Completion is not independent correctness.

| Task | Method | Accounted completion | Known-only utility AUC | AUC known / scheduled |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 1 | 0.0246555 | 2 / 2 |
| Sphere | HillClimb | 1 | 0.0240204 | 2 / 2 |
| Sphere | FixedMapElites | 1 | 0.0237467 | 2 / 2 |
| Sphere | AdaptiveMapElites | 1 | 0.0237467 | 2 / 2 |
| Sphere | UniformPortfolioMapElites | 1 | 0.0237467 | 2 / 2 |
| Sphere | DiagonalCma | 1 | 0.0235835 | 2 / 2 |
| ShiftedQuadratic | RandomSearch | 1 | 0.022855 | 2 / 2 |
| ShiftedQuadratic | HillClimb | 1 | 0.0208638 | 2 / 2 |
| ShiftedQuadratic | FixedMapElites | 1 | 0.020598 | 2 / 2 |
| ShiftedQuadratic | AdaptiveMapElites | 1 | 0.020598 | 2 / 2 |
| ShiftedQuadratic | UniformPortfolioMapElites | 1 | 0.0206065 | 2 / 2 |
| ShiftedQuadratic | DiagonalCma | 1 | 0.020471 | 2 / 2 |
| AnisotropicQuadratic | RandomSearch | 1 | 0.00120068 | 2 / 2 |
| AnisotropicQuadratic | HillClimb | 1 | 0.0011975 | 2 / 2 |
| AnisotropicQuadratic | FixedMapElites | 1 | 0.00116726 | 2 / 2 |
| AnisotropicQuadratic | AdaptiveMapElites | 1 | 0.00116726 | 2 / 2 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 1 | 0.00116726 | 2 / 2 |
| AnisotropicQuadratic | DiagonalCma | 1 | 0.00119971 | 2 / 2 |
| RippledQuadratic | RandomSearch | 1 | 0.0081765 | 2 / 2 |
| RippledQuadratic | HillClimb | 1 | 0.00786764 | 2 / 2 |
| RippledQuadratic | FixedMapElites | 1 | 0.00771224 | 2 / 2 |
| RippledQuadratic | AdaptiveMapElites | 1 | 0.00783289 | 2 / 2 |
| RippledQuadratic | UniformPortfolioMapElites | 1 | 0.00769969 | 2 / 2 |
| RippledQuadratic | DiagonalCma | 1 | 0.00860306 | 2 / 2 |

Correctness pass rate, numerical error, runtime speedup, memory, undeclared targets,
common-grid coverage and normalized QD score are **unknown**, not zero or inferred from completion.
Actual available resource totals and their unknown-run counts are retained in JSON.
Declared target rates include all scheduled runs; non-hits are censored at the budget with unknown trajectories flagged separately.

## Budget-indexed progress

Known-only medians; missing curves are not interpolated.

| Task | Method | Cost units | Known / scheduled | Median loss |
| --- | --- | ---: | ---: | ---: |
| Sphere | RandomSearch | 8 | 2 / 2 | 32.6283 |
| Sphere | RandomSearch | 16 | 2 / 2 | 26.0139 |
| Sphere | HillClimb | 8 | 2 / 2 | 32.6283 |
| Sphere | HillClimb | 16 | 2 / 2 | 31.0888 |
| Sphere | FixedMapElites | 8 | 2 / 2 | 32.6283 |
| Sphere | FixedMapElites | 16 | 2 / 2 | 32.1788 |
| Sphere | AdaptiveMapElites | 8 | 2 / 2 | 32.6283 |
| Sphere | AdaptiveMapElites | 16 | 2 / 2 | 32.1788 |
| Sphere | UniformPortfolioMapElites | 8 | 2 / 2 | 32.6283 |
| Sphere | UniformPortfolioMapElites | 16 | 2 / 2 | 32.1788 |
| Sphere | DiagonalCma | 8 | 2 / 2 | 32.6283 |
| Sphere | DiagonalCma | 16 | 2 / 2 | 32.6283 |
| ShiftedQuadratic | RandomSearch | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | RandomSearch | 16 | 2 / 2 | 24.7118 |
| ShiftedQuadratic | HillClimb | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | HillClimb | 16 | 2 / 2 | 37.9035 |
| ShiftedQuadratic | FixedMapElites | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | FixedMapElites | 16 | 2 / 2 | 39.0487 |
| ShiftedQuadratic | AdaptiveMapElites | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | AdaptiveMapElites | 16 | 2 / 2 | 39.0487 |
| ShiftedQuadratic | UniformPortfolioMapElites | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | UniformPortfolioMapElites | 16 | 2 / 2 | 38.7708 |
| ShiftedQuadratic | DiagonalCma | 8 | 2 / 2 | 39.6654 |
| ShiftedQuadratic | DiagonalCma | 16 | 2 / 2 | 39.6654 |
| AnisotropicQuadratic | RandomSearch | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | RandomSearch | 16 | 2 / 2 | 728.115 |
| AnisotropicQuadratic | HillClimb | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | HillClimb | 16 | 2 / 2 | 755.104 |
| AnisotropicQuadratic | FixedMapElites | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | FixedMapElites | 16 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | AdaptiveMapElites | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | AdaptiveMapElites | 16 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | UniformPortfolioMapElites | 16 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | DiagonalCma | 8 | 2 / 2 | 812.865 |
| AnisotropicQuadratic | DiagonalCma | 16 | 2 / 2 | 720.118 |
| RippledQuadratic | RandomSearch | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | RandomSearch | 16 | 2 / 2 | 97.5901 |
| RippledQuadratic | HillClimb | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | HillClimb | 16 | 2 / 2 | 89.5577 |
| RippledQuadratic | FixedMapElites | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | FixedMapElites | 16 | 2 / 2 | 113.438 |
| RippledQuadratic | AdaptiveMapElites | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | AdaptiveMapElites | 16 | 2 / 2 | 103.998 |
| RippledQuadratic | UniformPortfolioMapElites | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | UniformPortfolioMapElites | 16 | 2 / 2 | 114.359 |
| RippledQuadratic | DiagonalCma | 8 | 2 / 2 | 123.831 |
| RippledQuadratic | DiagonalCma | 16 | 2 / 2 | 83.9531 |

## Paired win / tie / loss counts

Exact utility differences; failures remain paired.

- DiagonalCma versus RandomSearch: 2 / 2 / 4.
- DiagonalCma versus HillClimb: 3 / 0 / 5.
- DiagonalCma versus FixedMapElites: 3 / 3 / 2.
- DiagonalCma versus AdaptiveMapElites: 3 / 3 / 2.
- DiagonalCma versus UniformPortfolioMapElites: 3 / 3 / 2.

Task-level exploratory intervals, budget-indexed progress, independent resource counters and every run are in `report.json`.
Full unaggregated trajectories remain in the original input, identified by its SHA-256 in the report.
